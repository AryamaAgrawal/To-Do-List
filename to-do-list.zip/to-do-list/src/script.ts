var myList = document.getElementsByTagName("ul");
var i;
for (i=0;i<myList.length;i++){
  var box = document.createElement("SPAN");
  var textbox = document.createTextNode("×");
  box.className = "close";
  box.appendChild(textbox);
  myList[i].appendChild(box);
}

// Click on a close button to hide the current list item
var cls = document.getElementsByClassName("close");
var i;
for(i=0;i< cls.length;i++){
  cls[i].onclick= function(){
    var remove= this.parentElement;
    remove.style.display= "none";
  };
}


// Add a "checked" symbol when clicking on a list item
var todolist=document.querySelector("ul");
todolist.addEventListener('click',function(ev){
  if(ev.target.tagName==='LI'){
    ev.target.classList.toggle('checked');
  }
});


// Create a new list item when clicking on the "Add" button
function addtask(){
  var newTask = document.createElement("li");
  var newValue = document.getElementById("text").value;
  var newNode = document.createTextNode(newValue);
  newTask.appendChild(newNode);
  if(newValue===''){
    alert("You must write something");
  }
  else{
    document.getElementById("myUL").appendChild(newTask);
  }
  var box = document.createElement("SPAN");
  var textbox = document.createTextNode("×");
  box.className = "close";
  box.appendChild(textbox);
  newTask.appendChild(box);
  
  for(i=0;i<cls.length;i++){
    cls[i].onclick= function(){
    var remove= this.parentElement;
    remove.style.display= "none";
    } 
  }
}



//Clearing the entire list when clicking on the "Clear All" button
function clearall(){
  var todolist=document.getElementById("myUL");
  while(todolist.childNodes.length>0){
    todolist.removeChild(todolist.firstChild);
  }
}
var clearbtn = document.getElementById("clear");
clearbtn.addEventListener("click",clearall);